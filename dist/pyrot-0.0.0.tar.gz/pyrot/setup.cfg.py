[metadata]
name = pyrot
license_files = LICENSE.txt

[options]
package_dir=
    =src
packages=find:

[options.packages.find]
where=src