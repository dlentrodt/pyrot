[build-system]
requires = ["setuptools", "numpy", "scipy", "matplotlib"]
build-backend = "setuptools.build_meta"